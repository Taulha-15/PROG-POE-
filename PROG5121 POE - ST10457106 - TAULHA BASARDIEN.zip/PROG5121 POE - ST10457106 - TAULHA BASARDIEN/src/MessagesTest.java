import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MessagesTest
{

    private Messages messages;

    @BeforeEach
    public void setUp()
    {
        messages = new Messages();
    }

    @Test
    public void testSendMessage()
    {
        
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.sendMessage("1234567890", "Hello, this is a test message.");

        String output = outContent.toString().trim();
        assertTrue(output.contains("Message sent successfully"));
        assertEquals(1, messages.getSentMessages().size());
    }

    @Test
    public void testShowSentMessages_NoMessages()
    {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.showSentMessages();

        String output = outContent.toString().trim();
        assertEquals("No messages sent.", output);
    }

    @Test
    public void testShowSentMessages_WithMessages()
    {
        messages.sendMessage("1234567890", "Hello, this is a test message.");

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.showSentMessages();

        String output = outContent.toString().trim();
        assertTrue(output.contains("MessageID:"));
    }

    @Test
    public void testDisplayLongestMessage_NoMessages()
    {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.displayLongestMessage();

        String output = outContent.toString().trim();
        assertEquals("No messages sent.", output);
    }

    @Test
    public void testDisplayLongestMessage_WithMessages()
    {
        messages.sendMessage("1234567890", "Short message.");
        messages.sendMessage("0987654321", "This is a much longer message than the previous one.");

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.displayLongestMessage();

        String output = outContent.toString().trim();
        assertTrue(output.contains("Longest Message:"));
        assertTrue(output.contains("This is a much longer message than the previous one."));
    }

    @Test
    public void testSearchMessageById_MessageFound()
    {
        messages.sendMessage("1234567890", "Hello, this is a test message.");
        String messageId = messages.getSentMessages().get(0).getMessageId();

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.searchMessageById(messageId);

        String output = outContent.toString().trim();
        assertTrue(output.contains("Message found:"));
    }

    @Test
    public void testSearchMessageById_MessageNotFound()
    {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.searchMessageById("nonexistent_id");

        String output = outContent.toString().trim();
        assertEquals("Message ID not found.", output);
    }

    @Test
    public void testSearchMessagesByRecipient_MessageFound()
    {
        messages.sendMessage("1234567890", "Hello, this is a test message.");

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.searchMessagesByRecipient("1234567890");

        String output = outContent.toString().trim();
        assertTrue(output.contains("Message to 1234567890:"));
    }

    @Test
    public void testSearchMessagesByRecipient_NoMessagesFound()
    {

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.searchMessagesByRecipient("nonexistent_recipient");

        String output = outContent.toString().trim();
        assertEquals("No messages found for this recipient.", output);
    }

    @Test
    public void testDeleteMessageById_MessageDeleted()
    {
        messages.sendMessage("1234567890", "Hello, this is a test message.");
        String messageId = messages.getSentMessages().get(0).getMessageId();

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.deleteMessageById(messageId);

        String output = outContent.toString().trim();
        assertEquals("Message deleted successfully.", output);
        assertEquals(0, messages.getSentMessages().size());
    }

    @Test
    public void testDeleteMessageById_MessageNotFound()
    {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.deleteMessageById("nonexistent_id");

        String output = outContent.toString().trim();
        assertEquals("Message ID not found.", output);
    }

    @Test
    public void testDisplayReport_NoMessages()
    {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.displayReport();

        String output = outContent.toString().trim();
        assertEquals("No messages sent.", output);
    }

    @Test
    public void testDisplayReport_WithMessages()
    {
        messages.sendMessage("1234567890", "Hello, this is a test message.");

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        messages.displayReport();

        String output = outContent.toString().trim();
        assertTrue(output.contains("Message Report:"));
    }
}