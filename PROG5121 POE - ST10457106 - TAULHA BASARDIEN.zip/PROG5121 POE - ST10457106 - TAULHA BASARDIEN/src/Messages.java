import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Messages
{
    private List<Message> sentMessages = new ArrayList<>();
    private List<Message> disregardedMessages = new ArrayList<>();
    private List<Message> storedMessages = new ArrayList<>();

    // This method displays a menu and allows user full access to their history on QuickChat.
    public void displayMenu()
    {
        while (true) {
            System.out.println("Welcome to QuickChat.");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Sent Messages");
            System.out.println("3) Display Longest Message");
            System.out.println("4) Search Message by ID");
            System.out.println("5) Search Messages by Recipient");
            System.out.println("6) Delete Message by ID");
            System.out.println("7) Display Report");
            System.out.println("8) Quit");
            System.out.print("Choose an option: ");
            int choice = new Scanner(System.in).nextInt();

            switch (choice)
            {
                case 1:
                    sendMessage();
                    break;
                case 2:
                    showSentMessages();
                    break;
                case 3:
                    displayLongestMessage();
                    break;
                case 4:
                    searchMessageById();
                    break;
                case 5:
                    searchMessagesByRecipientCellNumber();
                    break;
                case 6:
                    deleteMessageById();
                    break;
                case 7:
                    displayReport();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Method to send a message
    public void sendMessage()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter recipient cell number: ");
        String recipient = scanner.nextLine();
        System.out.print("Enter message text: ");
        String messageText = scanner.nextLine();

    // Create a new message and add it to the sent messages list
        Message newMessage = new Message(recipient, messageText);
        sentMessages.add(newMessage);
        System.out.println("Message sent successfully: " + newMessage);
    }

    // Method to show sent messages
    public void showSentMessages()
    {
        if (sentMessages.isEmpty())
        {
            System.out.println("No messages sent.");
        }
        else
        {
            for (Message message : sentMessages)
            {
                System.out.println(message);
            }
        }
    }

    // Method to display the longest message
    public void displayLongestMessage()
    {
        if (sentMessages.isEmpty())
        {
            System.out.println("No messages sent.");
            return;
        }

        Message longestMessage = sentMessages.get(0);

        for (Message message : sentMessages)
        {
            if (message.getMessageText().length() > longestMessage.getMessageText().length())
            {
                longestMessage = message;
            }
        }
        System.out.println("Longest Message: " + longestMessage);
    }

    // Method to search for a message by ID
    public void searchMessageById()
    {
        System.out.print("Enter Message ID to search: ");
        String messageId = new Scanner(System.in).nextLine();
        boolean found = false;

        for (Message message : sentMessages)
        {
            if (message.getMessageId().equals(messageId))
            {
                System.out.println("Message found: " + message);
                found = true;
                break;
            }
        }
        if (!found)
        {
            System.out.println("Message ID not found.");
        }
    }

    // Method to search messages by recipients cell number
    public void searchMessagesByRecipientCellNumber()
    {
        System.out.print("Enter recipient cell number to search: ");
        String recipient = new Scanner(System.in).nextLine();
        boolean found = false;

        for (Message message : sentMessages)
        {
            if (message.getRecipient().equals(recipient))
            {
                System.out.println("Message to " + recipient + ": " + message);
                found = true;
            }
        }
        if (!found)
        {
            System.out.println("No messages found for this recipient.");
        }
    }

    // Method to delete a message by ID
    public void deleteMessageById()
    {
        System.out.print("Enter Message ID to delete: ");
        String messageId = new Scanner(System.in).nextLine();
        boolean deleted = false;

        for (int i = 0; i < sentMessages.size(); i++)
        {
            if (sentMessages.get(i).getMessageId().equals(messageId))
            {
                sentMessages.remove(i);
                System.out.println("Message deleted successfully.");
                deleted = true;
                break;
            }
        }
        if (!deleted)
        {
            System.out.println("Message ID not found.");
        }
    }

    // Method to display a report of all sent messages
    public void displayReport()
    {
        if (sentMessages.isEmpty())
        {
            System.out.println("No messages sent.");
            return;
        }

        System.out.println("Message Report:");
        for (Message message : sentMessages)
        {
            System.out.println(message);
        }
    }

    // Main method to run the application
    public static void main(String[] args)
    {
        Messages app = new Messages();
        app.displayMenu();
    }
}

class Message
{
    private static final Random random = new Random();
    private String messageId;
    private String recipient;
    private String messageText;

    // Constructor
    public Message(String recipient, String messageText)
    {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageId = generateMessageId();
    }

    // Method to generate a unique message ID
    private String generateMessageId()
    {
        // Generate a random 10-digit number
        return String.format("%010d", random.nextInt(1000000000));
    }

    public String getMessageId()
    {
        return messageId;
    }

    public String getRecipient()
    {
        return recipient;
    }

    public String getMessageText()
    {
        return messageText;
    }

    @Override
    public String toString()
    {
        return "MessageID: " + messageId + ", Recipient: " + recipient + ", Message: " + messageText;
    }
}
