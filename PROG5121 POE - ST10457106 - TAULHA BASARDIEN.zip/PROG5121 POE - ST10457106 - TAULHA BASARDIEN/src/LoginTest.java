import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LoginTest
{

    private Login login;

    @BeforeEach
    public void setUp()
    {
        login = new Login();
    }

    @Test
    public void testCheckUser Name_Valid()
    {
        assertTrue(login.checkUser Name("user_"));
    }

    @Test
    public void testCheckUser Name_Invalid_NoUnderscore()
    {
        assertFalse(login.checkUser Name("user"));
    }

    @Test
    public void testCheckUser Name_Invalid_TooLong()
    {
        assertFalse(login.checkUser Name("user_name"));
    }

    @Test
    public void testCheckPasswordComplexity_Valid()
    {
        assertTrue(login.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_TooShort()
    {
        assertFalse(login.checkPasswordComplexity("Pass1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoUppercase()
    {
        assertFalse(login.checkPasswordComplexity("password1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoNumber()
    {
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoSpecialChar()
    {
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    @Test
    public void testCheckCellPhoneNumber_Valid()
    {
        assertTrue(login.checkCellPhoneNumber("+27123456789"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_WrongPrefix()
    {
        assertFalse(login.checkCellPhoneNumber("0123456789"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_TooLong()
    {
        assertFalse(login.checkCellPhoneNumber("+271234567890"));
    }

    @Test
    public void testRegisterUser _Success()
    {
        String result = login.registerUser ("user_", "Password1!", "+27123456789");
        assertEquals("Registration successful!", result);
    }

    @Test
    public void testRegisterUser _InvalidUsername()
    {
        String result = login.registerUser ("username", "Password1!", "+27123456789");
        assertEquals("Invalid username format, username must contain an underscore and a maximum of five characters in length.", result);
    }

    @Test
    public void testRegisterUser _InvalidPassword()
    {
        String result = login.registerUser ("user_", "pass", "+27123456789");
        assertEquals("Invalid password format; password must contain a minimum of eight characters, a capital letter, a number, and a special character.", result);
    }

    @Test
    public void testRegisterUser _InvalidCellPhoneNumber()
    {
        String result = login.registerUser ("user_", "Password1!", "123456789");
        assertEquals("Invalid cell phone number format.", result);
    }

    @Test
    public void testLoginUser _Success()
    {
        login.registerUser ("user_", "Password1!", "+27123456789");
        assertTrue(login.loginUser ("user_", "Password1!"));
    }

    @Test
    public void testLoginUser _Failure()
    {
        login.registerUser ("user_", "Password1!", "+27123456789");
        assertFalse(login.loginUser ("user_", "WrongPassword"));
    }

    @Test
    public void testReturnLoginStatus_Success()
    {
        login.registerUser ("user_", "Password1!", "+27123456789");
        assertEquals("Welcome user_, you have successfully logged in!", login.returnLoginStatus(true));
    }

    @Test
    public void testReturnLoginStatus_Failure()
    {
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus(false));
    }
}
